from django.apps import AppConfig


class A4Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'A4'
